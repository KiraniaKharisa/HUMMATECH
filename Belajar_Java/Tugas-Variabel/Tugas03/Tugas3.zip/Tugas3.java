// Soal ada pada gambar
// Apa itu variabel biasa
// Sebuah wadah untuk menyimpan nilai sementara berdasarkan tipe data dan bisa dirubah nilai nya di tengah tengah progam
// Apa itu variabel konstanta
// Sama seperti variabel tetapi nilainya tidak bisa dirubah atau sudah pasti 

public class Tugas3 {
    public static void main(String[] args) {
        // Variabel biasa 
        String nama = "Kirania Kharisa";
        System.out.println("nama saya : " + nama);
        // ganti nama 
        nama = "Kirania";
        System.out.println("nama ganti : " + nama);
        
        // Variabel konstanta
        final double phi = 3.14;
        System.out.println("nilai phi : " + phi);
        // ganti phi
        // phi = 3.15;


    }
}
